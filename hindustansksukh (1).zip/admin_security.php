<style>
/* Import Google Fonts */
@import url("//fonts.googleapis.com/css2?family=Montserrat:ital,wght@0,300;0,400;0,500;0,600;0,700;1,300;1,400;1,500;1,600;1,700&display=swap");
@import url("//fonts.googleapis.com/css2?family=Inter:ital,wght@0,300;0,400;0,500;0,600;0,700;1,300;1,400;1,500;1,600;1,700&display=swap");
</style>
<?php
// List of authorized IPs
$authorized_ips = ['49.43.96.181'];

// Get the client's IP address
function get_client_ip() {
    if (!empty($_SERVER['HTTP_CLIENT_IP'])) {
        return $_SERVER['HTTP_CLIENT_IP'];
    } elseif (!empty($_SERVER['HTTP_X_FORWARDED_FOR'])) {
        return $_SERVER['HTTP_X_FORWARDED_FOR'];
    } else {
        return $_SERVER['REMOTE_ADDR'];
    }
}

$client_ip = get_client_ip();


$access = 'admin';
if (isset($_GET['access']) && $_GET['access'] === $access) {
    echo "";
} elseif (!in_array($client_ip, $authorized_ips)) {
    echo "
    <html>
    <head>
        <title>Access Denied</title>
        <style>
        
            body {
                background-color: #2c2c2c;
                font-family: 'Inter', sans-serif;
                text-align: center;
                padding: 50px;
                color: #fff;
            }
            .container {
               width: 100%;
    
    
    background-color: #2b2b2b;
    border-radius: 12px;
    box-shadow: 0 8px 16px rgba(0, 0, 0, 0.3);
        }
            h1 {
                color: #ff4b4b;
                font-size: 48px;
            }
            p {
                color: #ccc;
                font-size: 18px;
            }
            .ip-info {
            background: linear-gradient(145deg, #c71f1f, #e04d4d); /* Gradient background for a professional look */
  color: #ffffff; /* Text color */
  padding: 14px 28px; /* Padding for consistency with primary button */
  font-size: 16px; /* Font size */
  font-weight: 500; /* Font weight */
  border: none; /* Remove default border */
  border-radius: 5px; /* Slightly rounded corners */
  box-shadow: 0 4px 8px rgba(0, 0, 0, 0.3); /* Subtle shadow for depth */
  transition: background 0.3s ease, transform 0.2s ease; /* Smooth transition for hover effects */
}
.ip-info:hover {
    background: linear-gradient(145deg, #e04d4d, #f76c6c); /* Darker gradient on hover */
  transform: translateY(-2px); /* Slight lift effect */
}
            /* Heading */
.container h1{
 font-family:'Montserrat', sans-serif;
}

/* Paragraph */
.container p{
 font-family:'Inter', sans-serif;
}

/* Container */
.container{
 padding-top:10px;
 padding-bottom:50px;
}

/* Info */
.container .ip-info{
 font-family:'Inter', sans-serif;
}
/* Body */
body{
 background-color:#ffffff;
}

/* Container */
.container{
 background-color:#ffffff;
}

/* Heading */
.container h1{
 color:#5a5a5a;
}

/* Paragraph */
.container p{
 color:#5a5a5a;
}

/* Info */
.container .ip-info{
 background-image:linear-gradient(145deg, #007bff, #0056b3);
 text-align:center;
}



        </style>
    </head>
    
    <body>
        <div class='container'>
            <h1>Access Denied</h1>
            <p>Your IP address is not authorized to access this page.</p>
            <br>
            <div class='ip-info'>
                Your IP : $client_ip
                
            </div>
            
        </div>
   </body>
    </html>
    ";
    exit(); // Stop further execution of the script
}

// If the IP is authorized, allow access to the admin panel
?>
