<?php include 'header.php'; ?>
<style>
    body {
        background-color: #f9f9f9;
        font-family: 'Inter', sans-serif;
        color: #333;
    }

    .container-md {
        max-width: 800px;
        margin-top: 40px;
        padding: 20px;
        background: #fff;
        border-radius: 8px;
        box-shadow: 0 4px 12px rgba(0, 0, 0, 0.1);
    }

    h3 {
        font-weight: 600;
        margin-bottom: 20px;
        color: #333;
    }

    .form-group label {
        font-weight: 500;
        color: #555;
        margin-bottom: 8px;
    }

    .form-control {
        border: 1px solid #ced4da;
        border-radius: 5px;
        padding: 10px;
        font-size: 14px;
    }

    .form-control:focus {
        border-color: #007bff;
        box-shadow: 0 0 4px rgba(0, 123, 255, 0.2);
    }

    .btn-primary {
        background-color: #007bff;
        border-color: #007bff;
        color: #fff;
        padding: 10px 20px;
        font-size: 16px;
        border-radius: 5px;
        transition: background 0.3s;
    }

    .btn-primary:hover {
        background-color: #0056b3;
    }

    .btn-default {
        background-color: #6c757d;
        color: #fff;
        padding: 10px 20px;
        font-size: 16px;
        border-radius: 5px;
        margin-left: 10px;
    }

    .btn-default:hover {
        background-color: #5a6268;
    }

    hr {
        border-top: 1px solid #e0e0e0;
        margin-top: 20px;
        margin-bottom: 20px;
    }
    /* Accordion Content */
.col-md-12 .panel .panel-body{
 padding-top:0px;
 padding-bottom:0px;
}
/* Title */
#title{
 display: flex;
    align-items: center;
    background-color: #e9ecef; /* Light input background */
    border-radius: 8px;
    padding: 12px;
    color: #333; /* Dark text color */
    box-shadow: inset 0 2px 4px rgba(0, 0, 0, 0.1);
    min-height: 50px;
}

/* Broadcast type */
#broadcast_type{
display: flex;
    align-items: center;
    background-color: #e9ecef; /* Light input background */
    border-radius: 8px;
    padding: 12px;
    color: #333; /* Dark text color */
    box-shadow: inset 0 2px 4px rgba(0, 0, 0, 0.1);
    min-height: 50px;
}

/* Action link */
#action_link{
 display: flex;
    align-items: center;
    background-color: #e9ecef; /* Light input background */
    border-radius: 8px;
    padding: 12px;
    color: #333; /* Dark text color */
    box-shadow: inset 0 2px 4px rgba(0, 0, 0, 0.1);
    min-height: 50px;
}
/* Action text */
#action_text{
 display: flex;
    align-items: center;
    background-color: #e9ecef; /* Light input background */
    border-radius: 8px;
    padding: 12px;
    color: #333; /* Dark text color */
    box-shadow: inset 0 2px 4px rgba(0, 0, 0, 0.1);
    min-height: 50px;
}

/* Division */
.form .form-group:nth-child(5) .panel div:nth-child(3) > div:nth-child(3){
 
    background-color: #e9ecef; /* Light input background */
    border-radius: 8px;
    padding: 12px;
    color: #333; /* Dark text color */
    box-shadow: inset 0 2px 4px rgba(0, 0, 0, 0.1);
    min-height: 50px;
}

/* Expiry date */
.form-control{
 display: flex;
    align-items: center;
    background-color: #e9ecef; /* Light input background */
    border-radius: 8px;
    padding: 12px;
    color: #333; /* Dark text color */
    box-shadow: inset 0 2px 4px rgba(0, 0, 0, 0.1);
    min-height: 50px;
}

/* Status */
#status{
 display: flex;
    align-items: center;
    background-color: #e9ecef; /* Light input background */
    border-radius: 8px;
    padding: 12px;
    color: #333; /* Dark text color */
    box-shadow: inset 0 2px 4px rgba(0, 0, 0, 0.1);
    min-height: 50px;
}
.panel-body .form .btn-primary{
 background: linear-gradient(145deg, #007bff, #0056b3); /* Light gradient */
    color: #ffffff;
    padding: 14px 28px;
    font-size: 14px;
    font-weight: 500;
    border: none;
    border-radius: 5px;
    box-shadow: 0 4px 8px rgba(0, 0, 0, 0.1);
    transition: background 0.3s ease, transform 0.2s ease;
}

/* Button */
.panel-body .form a.btn{
 background: linear-gradient(145deg, #c71f1f, #e04d4d); /* Gradient background for a professional look */
  color: #ffffff; /* Text color */
  padding: 14px 28px;
  font-size: 14px; /* Font size */
  font-weight: 500; /* Font weight */
  border: none; /* Remove default border */
  border-radius: 5px; /* Slightly rounded corners */
  box-shadow: 0 4px 8px rgba(0, 0, 0, 0.3); /* Subtle shadow for depth */
  transition: background 0.3s ease, transform 0.2s ease; /* Smooth transition for hover effects */
}



</style>
          <div class="container container-md"> <div class="row"><div class="col-md-12">
  <div class="panel panel-default">
    <div class="panel-body">
  <center> <h3>Edit Broadcast</h3></center>

          <hr>
<form class="form" action="<?php echo site_url("admin/broadcasts/edit"); ?> " method="POST" >
<div class="form-group">
<label class="form-group__service-name">Title</label>
<input type="hidden" name="id" value="<?= $notifData['id']; ?>">
                <input type="text" class="form-control" name="title" value="<?= $notifData['title']; ?>" required>
              </div>
<div class="form-group">

<label class="form-group__service-name">Type</label>
<select class="form-control" name="broadcast_type">
<option value="info" <?php if($notifData['type']== "info"){ echo 'selected'; }?>>Info</option>
<option value="success" <?php if($notifData['type']== "success"){ echo 'selected'; }?>>Success</option>
<option value="error" <?php if($notifData['type']== "error"){ echo 'selected'; }?>>Error</option>
<option value="warning" <?php if($notifData['type']== "warning"){ echo 'selected'; }?>>Warning</option>
</select>
</div>
               <div class="form-group">
                        <label class="form-group__service-name">Action Link</label>
                        <input type="text" class="form-control" name="action_link" value="<?= $notifData['action_link']; ?>">
                </div>
                <div class="form-group">
                        <label class="form-group__service-name">Button Text (Optional)</label>
                        <input type="text" class="form-control" name="action_text" value="<?= $notifData['action_text']; ?>">
                </div>
                <div class="form-group">
                        <label class="form-group__service-name">Description</label>
         <textarea class="form-control" id="summernote" rows="5" name="description" placeholder="" required> <?= $notifData['description']; ?> </textarea>

                </div>

<div class="form-group">
                        <label class="form-group__service-name">Target Users</label>
                        <input type="radio" class="" name="isAllUser" value="0" <?php if ($notifData['isAllUser']==0) { echo 'checked'; } ?>> All Users</br>
                        <input type="radio" class="" name="isAllUser" value="1" <?php if ($notifData['isAllUser']==1) { echo 'checked'; } ?>> Logged-In User
                </div>
                <div class="form-group">
                        <label class="form-group__service-name">Expiry Date</label>
                        <input type="date" class="form-control" name="expiry_date" value="<?= $notifData['expiry_date']; ?>">
                </div>
                <div class="form-group">
                        <label class="form-group__service-name">Status</label>
                        <select class="form-control" name="status">
                                <option value="0" >Selected : <?php if($notifData['status']==0){echo "Inactive";}else{echo "Active";}  ?></option>
                            <option value="0" <?php if($notifData['status']==0){ echo 'selected'; } ?>>Inactive</option>
                            <option value="1" <?php if($notifData['status']==1){ echo 'selected'; } ?>>Active</option>
                        </select>    
                </div>
              <button type="submit" class="btn btn-primary">Update</button>  
         <a href="<?=site_url("admin/broadcasts")?>" class="btn btn-default">
         <span class="export-title">Go Back</span>
         </a>
        </form>
    
  


<?php include 'footer.php'; ?>
<script>
$('input#isAllPage').change(function() {
if ($('input#isAllPage').prop('checked')) {    
   $('div#allPages').hide();
}else{
    $('div#allPages').show();
}

});
</script>