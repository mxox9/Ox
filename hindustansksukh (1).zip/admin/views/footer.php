  <div class="modal fade" id="modalDiv" tabindex="-1" role="dialog" aria-labelledby="exampleModalLabel" aria-hidden="true">
   <div class="modal-dialog modal-lg" role="document">
     <div class="modal-content">
       <div class="modal-header">
         <button type="button" class="close" data-dismiss="modal" aria-label="Close"><span aria-hidden="true">×</span></button>
         <h4 class="modal-title" id="modalTitle"></h4>
       </div>
       <div id="modalContent">
       </div>
     </div>
   </div>
  </div>
  




  <div class="modal fade" id="subsDiv" tabindex="-1" role="dialog" aria-labelledby="exampleModalLabel" aria-hidden="true">
   <div class="modal-dialog modal-lg" role="document">
     <div class="modal-content">
       <div class="modal-header">
         <button type="button" class="close" data-dismiss="modal" aria-label="Close"><span aria-hidden="true">×</span></button>
         <h4 class="modal-title" id="subsTitle"></h4>
       </div>
       <div id="subsContent">
       </div>
     </div>
   </div>
  </div>
  <script type="text/javascript" src="//code.jquery.com/jquery-3.3.1.min.js"></script>
  <script type="text/javascript" src="//cdnjs.cloudflare.com/ajax/libs/moment.js/2.20.1/moment.min.js"></script>
  <script type="text/javascript" src="//maxcdn.bootstrapcdn.com/bootstrap/3.3.7/js/bootstrap.min.js"></script>
  <script src="//unpkg.com/sweetalert/dist/sweetalert.min.js"></script>
  <script src="//gitcdn.github.io/bootstrap-toggle/2.2.2/js/bootstrap-toggle.min.js"></script>
 <link href="https://cdn.jsdelivr.net/npm/summernote@0.8.18/dist/summernote.min.css" rel="stylesheet">
<script src="https://cdnjs.cloudflare.com/ajax/libs/bootstrap-select/1.8.1/js/bootstrap-select.js"></script>
  <script src="https://cdn.jsdelivr.net/npm/summernote@0.8.18/dist/summernote.min.js"></script>

  <script src="public/admin/toastDemo.js"></script>
  <script src="public/admin/script.js"></script>
  <script src="public/admin/script-2.js"></script>
  <script src="//code.jquery.com/ui/1.12.1/jquery-ui.min.js"></script>
  <script src="public/admin/jquery.tinytoggle.min.js"></script>
<script src="https://code.jquery.com/ui/1.13.2/jquery-ui.min.js" ></script>
<script src="https://cdnjs.cloudflare.com/ajax/libs/jqueryui-touch-punch/0.2.3/jquery.ui.touch-punch.min.js"></script>
<script src="public/admin/sortable-animation.js"></script>
<script src="https://itsjavi.com/fontawesome-iconpicker/dist/js/fontawesome-iconpicker.js"></script>
<script src="public/admin/image-picker.min.js"></script>
 <script src="https://cdnjs.cloudflare.com/ajax/libs/limonte-sweetalert2/11.10.6/sweetalert2.min.js"></script>
<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/limonte-sweetalert2/11.10.6/sweetalert2.css"/>

 
 <script type="text/javascript"> $.fn.TinyToggle={defaults:{type:"toggle",size:"medium",palette:"standard"},types:{dot:{checked:"tt-check-circle",unchecked:"tt-check-circle"}},palettes:{red:{check:"#CC0000",uncheck:"#999999"},green:{check:"#29bf12",uncheck:"#ef233c"}},sizes:{medium:"1.5em"}};$(document).ready(function(){$("#loading").hide(),$(".custom_method").on("click",function(t){t.preventDefault();var e,i,n,o,a={text:$(this).data("message"),title:$(this).data("title"),icon:"warning",showCancelButton:!0,confirmButtonColor:"#3085d6",cancelButtonColor:"#d33",confirmButtonText:"Okay",timer:1e4,timerProgressBar:!0},c=$(this).data("action"),d=$(this).data("id"),s=$(this).data("url"),r=$(this).data("main");s=(e=c,i=s,n=d,url="delete_service"==e?"admin/services/delete/"+n:i),Swal.fire(a).then(t=>{t.isConfirmed&&$.ajax({url:s,type:"POST",beforeSend:function(){$("#loading").show()},data:{action:c,method_id:d,main:r},success:function(t){console.log(t),$("#loading").hide(),t=JSON.parse(t),new swal(t.title,"",t.icon).then(function(e){"success"==t.icon&&(window.location.href=window.location.href)})}})})})});$(window).on("load",function(){$("#loading").hide()});$(document).ready(function(){var site_url  = $('head base').attr('href');<?php if( route(2) == "new-service" || route(2) == "new-subscription" ): echo '$(document).ready(function(){getProviderServices($("#provider").val(),site_url);});'; endif; ?>$(".buy-button").click(function(){var a=$(this).parent().attr("data-addon");window.location.href="admin/settings/modules?action=buy_addon&addon="+a}),$(".addon").change(function(){var a=$(this).attr("data-addon");$.ajax({url:"admin/settings/modules?action=toggle_addon&addon="+a,type:"GET",success:function(a){}})}),



$(document).on("change","#image-input",function(){var a=$("#upload_an_image");a.html('<span class="spinner-border spinner-border-sm" role="status" aria-hidden="true"></span> Uploading...'),a.attr("disabled","true");var e=$("#image-input").prop("files")[0],t=new FormData;t.append("logo",e),$.ajax({url:"admin/appearance/files",contentType:!1,processData:!1,cache:!1,data:t,type:"POST",success:function(e){a.html("Upload an Image"),a.removeAttr("disabled"),iziToast.show({icon:"fa fa-check",title:"Image uploaded successfully.",message:"",color:"green",position:"topCenter"});var t=$(".imagepicker-div");t.html('<center><svg class="spinner_2 medium" viewBox="0 0 48 48"><circle class="path_2" cx="24" cy="24" r="20" fill="none" stroke-width="3"></circle></svg></center><br><br>'),$.ajax({url:"admin/ajax_data",data:"action=download_category_icon_images",type:"POST",success:function(a){var a=JSON.parse(a);t.html(a.content),t.removeClass("load-images")}})}})}),$("#summernote").summernote({height:300}),$("#summernote1").summernote({height:300}),





$("#update_inr_rate").click(function(){$.ajax({url:site_url+"admin/ajax_data",data:"action=update_inr_rate",type:"POST",success:function(a){a=JSON.parse(a),$.toast({heading:"Success",text:"Rates Updated",icon:"success",loader:!0,loaderBg:"#9EC600"}),$("#inr_rate").val(a.rate)}})}),$(".check_seller_last_response").click(function(){$.ajax({url:"/admin/ajax_data",data:"action=seller_last_response&"+$(this).attr("data-action"),type:"POST",success:function(a){a=JSON.parse(a),$(".modal-title").html('Seller Last Response<br/><div class="label label-api">'+a.api_url+"</div>"),$(".modal-body").html(a.body)}})});$("#set_total_orders_pattern").click(function(){var t=$("#total_orders_prefix").val(),e=$("#total_orders_suffix").val();$.ajax({url:site_url+"admin/settings/site_count/total_orders_pattern",data:"total_orders_prefix="+t+"&total_orders_suffix="+e,type:"POST",success:function(t){iziToast.show({icon:"fa fa-check",title:"Changes saved.",message:"",color:"green",position:"topCenter"})}})});$("#choose_currency").change(function(){$code = $(this).val();$ht = $("#choose_currency > option:selected").html();$("#site_currency_btn").attr("data-href","<?php echo site_url("admin/settings/currency-manager");?>/"+$code+"");$("#site_currency_btn").html("Set Currency to "+$ht.replace("(Recommended for International Users)","").replace("(Recommended for Indian Users)","")+" ("+$code+")");});$("#enable-light-mode").click(function(){$.ajax({url:site_url+"admin/ajax_data",data:"action=enable-light-mode",type:"POST",success:function(a){window.location.reload()}})}),$("#enable-dark-mode").click(function(){$.ajax({url:site_url+"admin/ajax_data",data:"action=enable-dark-mode",type:"POST",success:function(a){window.location.reload()}})}),$("#enable-light-mode2").click(function(){$.ajax({url:site_url+"admin/ajax_data",data:"action=enable-light-mode",type:"POST",success:function(a){window.location.reload()}})}),$("#enable-dark-mode2").click(function(){$.ajax({url:site_url+"admin/ajax_data",data:"action=enable-dark-mode",type:"POST",success:function(a){window.location.reload()}})}),$(".currency-values-save-changes").click(function(a){a.preventDefault(),$data=($form=$(this).parent().parent().parent().parent().find("form")).serialize(),$.ajax({url:site_url+"admin/settings/currency-manager",data:"action=currency-values-save-changes&"+$data,type:"POST",success:function(a){iziToast.show({icon:"fa fa-check",title:"Changes saved.",message:"",color:"green",position:"topCenter"})}})}),


$("#activate_deactivate_curr_conv").click(function(){$.ajax({url:site_url+"admin/settings/currency-manager",data:"action=activate_deactivate_curr_conv",type:"POST",success:function(a){iziToast.show({icon:"fa fa-check",title:"Success",message:"",color:"green",position:"topCenter"})}})});$("#rate_update_switch").click(function(){$.ajax({url:site_url+"admin/settings/currency-manager",data:"action=rate_update_switch",type:"POST",success:function(t){iziToast.show({icon:"fa fa-check",title:"Success",message:"",color:"green",position:"topCenter"})}})}),$("#update-rates").click(function(){$.ajax({url:site_url+"admin/settings/currency-manager",data:"action=update_rates",type:"POST",success:function(t){iziToast.show({icon:"fa fa-check",title:"Currency Rates Updated.",message:"",color:"green",position:"topCenter"})}})}),



$("#next_order_id_value_btn").click(function(){var t=$("#next_order_id_value").val();$.ajax({url:site_url+"admin/ajax_data",data:"action=next_order_id&order_id="+t,type:"POST",success:function(t){var t=JSON.parse(t);1==t.success?iziToast.show({icon:"fa fa-check",title:t.message,message:"",color:"green",position:"topCenter"}):iziToast.show({icon:"fa fa-times",title:t.message,message:"",color:"red",position:"topCenter"})}})}),$(".delete-currency").click(function(){var t=$(this).attr("data-currency-id");


$.ajax({url:site_url+"admin/settings/currency-manager",data:"action=delete-currency&currency_id="+t,type:"POST",success:function(t){iziToast.show({icon:"fa fa-check",title:"Currency Deleted Successfully.",message:"",color:"green",position:"topCenter"}),window.location.reload()}})}),$(document).on("click",".category-visible",function(){var t=$(this);$.ajax({url:"admin/ajax_data",data:"action=category_disable&"+$(this).data("post"),type:"POST",success:function(a){var a=JSON.parse(a);t.replaceWith(a.content)}})}),$(document).on("click",".category-invisible",function(){var t=$(this);$.ajax({url:"admin/ajax_data",data:"action=category_enable&"+$(this).data("post"),type:"POST",success:function(a){var a=JSON.parse(a);t.replaceWith(a.content)}})}),


$("#modalDiv").on('shown.bs.modal', function() {
  $('#custom-payment-content').summernote({
height: 300,
tabsize: 2
});
});

$(".service-sortable").sortable({
handle: '.handle',
items : '> .ui-state-default',
animation:200,
opacity: 0.75,
revert: 50,
update: function(event, ui) {
var array = [];
$(this).find('tr').each(function(i) {
$(this).attr('data-line',i+1);
var params = {};
params['id']   = $(this).attr('data-id');
params['line'] = $(this).attr('data-line');
array.push(params);
});
$.post(site_url+'admin/ajax_data',{action:'service-sortable',services:array});
}
});

$(".methods-sortable").sortable({
handle: '.handle',
update: function(event, ui) {
var array = [];
$(this).find('tr').each(function(i) {
$(this).attr('data-line',i+1);
var params = {};
params['id']   = $(this).attr('data-id');
params['line'] = $(this).attr('data-line');
array.push(params);
});
$.post(site_url+'admin/ajax_data',{action:'paymentmethod-sortable',methods:array});
}
});


$(".menu-sortable").sortable({handle:".handle",update:function(t,a){var e=[];$(this).find("tr").each(function(t){$(this).attr("data-line",t+1);var a={};a.id=$(this).attr("data-id"),a.line=$(this).attr("data-line"),e.push(a)}),$.post(site_url+"admin/ajax_data",{action:"menu-sortable",menus:e})}}),$(".category-sortable").sortable({handle:".handle",items:"> .categories",animation:200,opacity:.75,revert:100,update:function(t,a){var e=[];$(this).find(".categories").each(function(t){$(this).attr("data-line",t+1);var a={};a.id=$(this).attr("data-id"),a.line=$(this).attr("data-line"),e.push(a)}),$.post(site_url+"admin/ajax_data",{action:"category-sortable",categories:e})}});});$(function () {$('[data-toggle="tooltip"]').tooltip()});<?php if( route(2) == "themes" && route(3) ): ?>(function () {var codeMirroSetting = {},codeType = '<?=$codeType;?>';switch (codeType){case 'twig':codeMirroSetting = {mode : "text/html",lineNumbers : true,profile: 'xhtml',lineWrapping: true,extraKeys: {"Ctrl-Q": function(cm){ cm.foldCode(cm.getCursor()); }},foldGutter: true,gutters: ["CodeMirror-linenumbers", "CodeMirror-foldgutter"],onKeyEvent: function(i, e) { if ((e.keyCode == 122 || e.keyCode == 27) && e.type == 'keydown') {e.stop();return toggleFullscreenEditing();}},};







break;case 'css':codeMirroSetting={mode:"text/css",lineNumbers:!0,lineWrapping:!0,extraKeys:{"Ctrl-Q":function(e){e.foldCode(e.getCursor())}},foldGutter:!0,gutters:["CodeMirror-linenumbers","CodeMirror-foldgutter"],onKeyEvent:function(e,r){if((122==r.keyCode||27==r.keyCode)&&"keydown"==r.type)return r.stop(),toggleFullscreenEditing()}};break;case 'js':codeMirroSetting={mode:"text/javascript",lineNumbers:!0,lineWrapping:!0,extraKeys:{"Ctrl-Q":function(e){e.foldCode(e.getCursor())}},foldGutter:!0,gutters:["CodeMirror-linenumbers","CodeMirror-foldgutter"],onKeyEvent:function(e,r){if((122==r.keyCode||27==r.keyCode)&&"keydown"==r.type)return r.stop(),toggleFullscreenEditing()}};break;default:codeMirroSetting={lineNumbers:!0,lineWrapping:!0,foldGutter:!0,gutters:["CodeMirror-linenumbers","CodeMirror-foldgutter"],onKeyEvent:function(e,r){if((122==r.keyCode||27==r.keyCode)&&"keydown"==r.type)return r.stop(),toggleFullscreenEditing()}};break;}CodeMirror.fromTextArea(document.getElementById("code"), codeMirroSetting);function toggleFullscreenEditing(){var e=$(".CodeMirror-scroll");e.hasClass("fullscreen")?(e.removeClass("fullscreen"),e.height(toggleFullscreenEditing.beforeFullscreen.height),e.width(toggleFullscreenEditing.beforeFullscreen.width),editor.refresh(),$(".fullscreen-blockFull").remove()):(toggleFullscreenEditing.beforeFullscreen={height:e.height(),width:e.width()},e.addClass("fullscreen"),e.height("100%"),e.width("100%"),editor.refresh(),e.append('<div class="fullscreen-blockFull"><a href="#" class="btn btn-sm btn-default fullScreenButtonOff"><span class="fa fa-compress" style="font-size: 18px; position: absolute; left: 6px; top: 4px;"></span></a> </div>'))}$(document).on("click",".fullScreenButton",function(n){toggleFullscreenEditing()}),$(document).on("click",".fullScreenButtonOff",function(n){toggleFullscreenEditing()}),$(document).keyup(function(n){27==n.keyCode&&$(".fullscreen").length>=1&&toggleFullscreenEditing()});})();<?php endif; ?></script>
</body>
</html>