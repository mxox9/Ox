<style>
/* Row */
.container .row{
 background-color:#ffffff;
}

/* Accordion Content */
.col-md-8 .panel .panel-body{
 background-color:#ffffff !important;
}

/* New */
.form-control[disabled], .form-control[readonly], fieldset[disabled] .form-control {
 display: flex;
    align-items: center;
    background-color: #e9ecef; /* Light input background */
    border-radius: 8px;
    padding: 12px;
    color: #333; /* Dark text color */
    box-shadow: inset 0 2px 4px rgba(0, 0, 0, 0.1);
    min-height: 50px;
}


body{
 font-family:'Inter', sans-serif;
            height: 100%;
            width: 100%;
            margin: 0;
            padding: 0;
            background-color:rgba(30,30,30,0) !important;
            color: #e0e0e0 !important ; /* Light gray text */
}
/* Accordion Content */
.col-md-8 .panel .panel-body{
 width: 100%;
     border-style:none;
   
    background-color: #2b2b2b;
    border-radius: 12px;
    box-shadow: 0 8px 16px rgba(0, 0, 0, 0.3);
}
.container .panel{
 border-style:none !important;
 border-width:0px !important;
 border-top-left-radius:12px;
 border-top-right-radius:12px;
 border-bottom-left-radius:12px;
 border-bottom-right-radius:12px;
}
/* Label */
.panel-body form label{
 font-weight:600;
 font-size:16px;
}

/* Heading */
.panel .panel-body h4{
 font-weight:600;
 font-size:16px;
}


/* List Item */
.panel-body ul li{
 padding-bottom:10px;
 padding-top:10px;
 padding-left:10px;
 padding-right:10px;
 
}

/* Button */
.panel-body form .btn{
    
 background: linear-gradient(145deg, #007bff, #0056b3); /* Light gradient */
    color: #ffffff;
    padding: 14px 28px;
    font-size: 14px;
    font-weight: 500;
    border: none;
    border-radius: 5px;
    box-shadow: 0 4px 8px rgba(0, 0, 0, 0.1);
    transition: background 0.3s ease, transform 0.2s ease;
}
  .panel-body form .btn:hover {
    background: linear-gradient(145deg, #0056b3, #003c82);
    transform: translateY(-2px);
}
/* Button */
.panel-body ul .btn-danger{
 background: linear-gradient(145deg, #c71f1f, #e04d4d); /* Gradient background for a professional look */
  color: #ffffff; /* Text color */
  position:relative;
 left:10px;
  font-size: 14px; /* Font size */
  font-weight: 500; /* Font weight */
  border: none; /* Remove default border */
  border-radius: 5px; /* Slightly rounded corners */
  box-shadow: 0 4px 8px rgba(0, 0, 0, 0.3); /* Subtle shadow for depth */
  transition: background 0.3s ease, transform 0.2s ease; /* Smooth transition for hover effects */
}
.panel-body ul .btn-danger:hover {
  background: linear-gradient(145deg, #e04d4d, #f76c6c); /* Darker gradient on hover */
  transform: translateY(-2px); /* Slight lift effect */
}
</style>
<div class="col-md-8">
  <div class="panel panel-default">
    <div class="panel-body">
      <form action="" method="post">
        <div class="form-group">
          <label for="cron_job">Autolike :</label>
          <input type="text" class="form-control" id="cron_job" name="cron_job" value="wget --spider -O -https://yourdomain.com/cronjobs/autolike.php" readonly required>
        </div>
        <div class="form-group">
          <label for="cron_job">Orders :</label>
          <input type="text" class="form-control" id="cron_job" name="cron_job" value="wget --spider -O -https://yourdomain.com/cronjobs/orders.php" readonly required>
        </div>
        <div class="form-group">
          <label for="cron_job">Auto-Reply :</label>
          <input type="text" class="form-control" id="cron_job" name="cron_job" value="wget --spider -O -
https://yourdomain.com/cronjobs/autoreply.php  " readonly required>
        </div>
        <div class="form-group">
          <label for="cron_job">Drip-Feed :</label>
          <input type="text" class="form-control" id="cron_job" name="cron_job" value="wget --spider -O -
https://Your_Domin/cronjobs/dripfeed.php" readonly required>
        </div>
        <div class="form-group">
          <label for="cron_job">Payments :</label>
          <input type="text" class="form-control" id="cron_job" name="cron_job" value="wget --spider -O -
https://Your_Domin/cronjobs/payments.php " readonly required>
        </div>
        <div class="form-group">
          <label for="cron_job">Refill :</label>
          <input type="text" class="form-control" id="cron_job" name="cron_job" value="wget --spider -O -
https://Your_Domin/cronjobs/refill.php" readonly required>
        </div>
        <div class="form-group">
          <label for="cron_job">Seller Sync :</label>
          <input type="text" class="form-control" id="cron_job" name="cron_job" value="wget --spider -O -
https://Your_Domin/cronjobs/seller-sync.php" readonly required>
        </div>
        <div class="form-group">
          <label for="cron_job">Average Time :</label>
          <input type="text" class="form-control" id="cron_job" name="cron_job" value="wget --spider -O -
https://Your_Domin/cronjobs/average.php" readonly required>
        </div>
        <script>
  // Get the current domain name
  const currentDomain = window.location.hostname;

  // Get all input fields with the name 'cron_job'
  const inputs = document.querySelectorAll('input[name="cron_job"]');

  // Loop through all the inputs and update the value with the current domain
  inputs.forEach(input => {
    input.value = input.value.replace(/https:\/\/(yourdomain\.com|Your_Domin)/, `https://${currentDomain}`);
  });
</script>
      </form>
    </div>
  </div>
</div>
