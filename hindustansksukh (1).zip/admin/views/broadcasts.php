<style>
/* Import Google Fonts */
@import url("//fonts.googleapis.com/css2?family=Inter:ital,wght@0,300;0,400;0,500;0,600;0,700;1,300;1,400;1,500;1,600;1,700&display=swap");

/* Accordion Content */
.col-md-12 .panel .panel-body{
 font-family:'Inter', sans-serif;
}

/* Body */
body{
 font-family:'Inter', sans-serif;
}


</style>
<?php include 'header.php'; ?>

<style>
    body {
        background-color: #f9f9f9;
        font-family: 'Inter', sans-serif;
        color: #333;
    }

    .btn-default, .btn-info, .btn-danger {
        border-radius: 5px;
        padding: 8px 16px;
        font-size: 14px;
        font-weight: 500;
    }

    .btn-default {
        background-color: #007bff;
        color: #fff;
        transition: background 0.3s, box-shadow 0.2s;
    }

    .btn-default:hover {
        background-color: #0056b3;
        box-shadow: 0 4px 8px rgba(0, 0, 0, 0.1);
    }

    .btn-info {
        background-color: #17a2b8;
    }

    .btn-danger {
        background-color: #dc3545;
    }

    

    .nav-tabs {
        font-family: 'Inter', sans-serif;
        margin-bottom: 20px;
    }

    .nav-tabs .btn {
        width:100%;
        background: linear-gradient(145deg, #007bff, #0056b3); /* Light gradient */
    color: #ffffff;
    padding: 14px 28px;
    font-size: 14px;
    font-weight: 500;
    border: none;
    border-radius: 5px;
    box-shadow: 0 4px 8px rgba(0, 0, 0, 0.1);
    transition: background 0.3s ease, transform 0.2s ease;
}

    .nav-tabs .btn:hover {
        color: #ffffff !important;
        background: linear-gradient(145deg, #0056b3, #003c82);
    transform: translateY(-2px);
}

    .table thead {
        background-color: #f1f3f5;
        color: #333;
        font-weight: 600;
        text-transform: uppercase;
    }

    .table th, .table td {
        vertical-align: middle;
        text-align: center;
        padding: 12px;
    }

    .badge {
        padding: 8px 12px;
        border-radius: 5px;
    }

    .badge-primary {
        background-color: #007bff;
    }

    .badge-secondary {
        background-color: #6c757d;
    }

    .badge-success {
        background-color: #28a745;
    }

    .badge-danger {
        background-color: #dc3545;
    }
    /* Button */
.table-striped tr a{
 
   width:100%;
    font-size: 14px;
    font-weight: 500;
    border: none !important;
    border-radius: 5px;
   
    transition: background 0.3s ease, transform 0.2s ease;
}

/* Button */
.table-striped tr a{
 border-top-left-radius:5px !important;
 border-bottom-left-radius:5px !important;
}

.card {
    border-radius: 8px;
    border: 1px solid #ddd;
    box-shadow: 0 4px 8px rgba(0, 0, 0, 0.1);
    overflow-x: auto;
}
/* Card body */
.container-fluid .card .card-body{
 border-style:none;
}

/* Table striped */
.card .card-body .table-striped{
 border-style:none;
}

.card {
    border-radius: 8px;
    border: 1px solid #ddd;
    box-shadow: 0 4px 8px rgba(0, 0, 0, 0.1);
    overflow-x: auto;
}
/* Card body */
.container-fluid .card .card-body{
 border-style:none;
}

/* Table striped */
.card .card-body .table-striped{
 border-style:none;
}
/* Button */
.table-striped tr a{
 background-color:rgba(23,162,184,0) !important;
 color:#0056b3;
 border-style:none;
}
.table-striped tr a:hover{
     background-color:rgba(23,162,184,0);
 color:#0056b3;
 border-style:none;
}
.btn-group>.btn:last-child:not(:first-child), .btn-group>.dropdown-toggle:not(:first-child){
     background-color:rgba(23,162,184,0);
 color:#0056b3;
 border-style:none;
}
/* Button */
.btn-group form .btn-danger{
 background-color:rgba(255,255,255,0);
 color:#ac2925;
 border-style:none;
}
.btn-group form .btn-danger:hover{
      background-color:rgba(255,255,255,0);
 color:#ac2925;
 border-style:none;
}
.btn-group form .btn-danger:active{
      background-color:rgba(255,255,255,0);
 color:#ac2925;
 border-style:none;
}
/* Th */
.table-striped tr th{
 font-size:14px;
 font-weight:600;
}

/* Table Data */
.table-striped tr td{
 font-size:14px;
}
/* Button */
.table-striped tr a{
 box-shadow:0px 4px 8px 0px rgba(0,0,0,0) !important;
}



</style>

<div class="container-fluid">
    <div class="row">
        <div class="col-md-12">
            <ul class="nav nav-tabs">
                <a href="<?php echo site_url("admin/broadcasts/create") ?>" class="btn btn-default">Create Notifications</a>
            </ul>
            <div class="row">
                <div class="col-md-12">
                    <div class="card">
                        <div class="card-body table-responsive">
                            <table class="table table-striped order-table">
                                <thead>
                                    <tr>
                                        <th>ID</th>
                                        <th>Title</th>
                                        
                                        <th>Action Link</th>
                                        <th>All Users</th>
                                        <th>Date Expiry</th>
                                        <th>Status</th>
                                        <th>Action</th>
                                    </tr>
                                </thead>
                                <tbody>
                                    <?php foreach($notifications as $notification): ?>
                                        <tr>
                                            <td><?php echo $notification["id"] ?></td>
                                            <td><?php echo $notification["title"] ?></td>
                                            
                                            <td><?php echo $notification["action_link"]?></td>
                                            <td><?php echo $notification["isAllUser"] ? 'Yes' : 'No'; ?></td>
                                            <td><?php echo $notification["expiry_date"] ?></td>
                                            <td><?php echo $notification["status"] == 1 ? 'Active' : 'Inactive'; ?></td>
                                            <td>
                                                <div class="btn-group">
                                                    <form action="<?php echo site_url("admin/broadcasts/delete") ?>" method="post" onsubmit="return confirm('Do you want to delete it?');" style="display: inline;">
                                                        <input type="hidden" name="notification_id" value="<?php echo $notification["id"] ?>">
                                                        <button type="submit" class="btn btn-danger">Delete</button>
                                                    </form>
                                                    <a href="<?php echo site_url("admin/broadcasts/edit/".$notification["id"]) ?>" class="btn btn-info">Edit</a>
                                                </div>
                                            </td>
                                        </tr>
                                    <?php endforeach; ?>
                                </tbody>
                            </table>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
</div>

<?php include 'footer.php'; ?>
