<?php include 'header.php'; ?>
<style>
/* Import Google Fonts */
@import url("//fonts.googleapis.com/css2?family=Inter:ital,wght@0,300;0,400;0,500;0,600;0,700;1,300;1,400;1,500;1,600;1,700&display=swap");

/* Panel */
.container .panel{
 border-top-left-radius:12px;
 border-top-right-radius:12px;
 border-bottom-left-radius:12px;
 border-bottom-right-radius:12px;
 border-style:none;
 box-shadow: 0 8px 16px rgba(0, 0, 0, 0.3);
 
}


/* Panel */
.container .panel {
    font-family: 'Inter', sans-serif;
    
}

/* Body */
body {
    font-family: 'Inter', sans-serif;
}

/* Heading */
.col-md-offset-2 .panel h6 {
    line-height: 1.5em;
    font-size: 16px;
    text-align: center;
    position: relative;
}

/* Heading */
.container .row .col-md-offset-2 .panel h6 {
    width: 100% !important;
}

/* Light Mode Styles */
body.light-mode {
    height: 100%;
    width: 100%;
    margin: 0;
    padding: 0;
    background-color: #f5f5f5; /* Light gray background */
    color: #333; /* Dark text color */
}

body.light-mode .panel {
    width: 100%;
    padding: 30px;
    background-color: #ffffff; /* White background */
    
    border-radius: 12px;
    box-shadow: 0 8px 16px rgba(0, 0, 0, 0.1);
}

.panel-body form input[type=password] {
    display: flex;
    align-items: center;
    background-color: #e9ecef; /* Light input background */
    border-radius: 8px;
    padding: 12px;
    color: #333; /* Dark text color */
    box-shadow: inset 0 2px 4px rgba(0, 0, 0, 0.1);
    min-height: 50px;
}

/* Placeholder color */
.panel-body form input[type=password]::placeholder {
    color: #999; /* Gray placeholder text */
}

h6 {
    text-align: center;
    color: #333; /* Dark text color */
    margin-bottom: 20px;
}

.panel-body form .btn-primary {
    width:100%;
    background: linear-gradient(145deg, #007bff, #0056b3); /* Light gradient */
    color: #ffffff;
    padding: 14px 28px;
    font-size: 14px;
    font-weight: 500;
    border: none;
    border-radius: 5px;
    box-shadow: 0 4px 8px rgba(0, 0, 0, 0.1);
    transition: background 0.3s ease, transform 0.2s ease;
}

.panel-body form .btn-primary:hover {
    background: linear-gradient(145deg, #0056b3, #003c82);
    transform: translateY(-2px);
}

/* Input */
.panel-body form input[type=password] {
    border-style: none;
}
</style>

<body>
    
<div class="container">
    <div class="row">
        <div class="col-md-8 col-md-offset-2">
            <div class="panel panel-default">
                <br>
                <h6>
                    To enhance your account security, please enter your current password and create a new, strong password for updating.
                </h6>
                <div class="panel-body">
                    <form action="admin/account" method="post" enctype="multipart/form-data">
                        <div class="form-group">
                            <label for="charge" class="control-label">Current Password</label>
                            <input type="password" class="form-control" value="" name="current_password" placeholder="Enter current password">
                        </div>

                        <div class="form-group">
                            <label for="charge" class="control-label">New Password</label>
                            <input type="password" class="form-control" value="" name="password" placeholder="Enter new password">
                        </div>

                        <div class="form-group">
                            <label for="charge" class="control-label">Password Again</label>
                            <input type="password" class="form-control" value="" name="confirm_password" placeholder="Re-enter new password">
                        </div>
                        <br>
                        <button type="submit" class="btn btn-primary">Change Password</button>
                    </form>
                </div>
            </div>
        </div>
    </div>
</div>
</body>
<?php include 'footer.php'; ?>
