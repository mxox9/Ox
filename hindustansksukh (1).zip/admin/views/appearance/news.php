<style>
  /* Light Theme Styles */
  body {
    font-family: 'Inter', sans-serif;
    background-color: #f7f9fc;
    color: #333333;
    margin: 0;
    padding: 0;
  }

  /* Nav Tabs and Button */
  .nav-tabs {
    border-bottom: none;
    margin-bottom: 15px;
  }

  .btn-default {
    background-color: #e0e4e7;
    color: #333333;
    border: none;
    padding: 8px 16px;
    font-weight: 500;
    transition: all 0.2s ease;
    border-radius: 5px;
  }

  .btn-default:hover {
    background-color: #cfd4da;
  }

  /* Table Styling */
  .table {
    border-collapse: separate;
    width: 100%;
    background-color: #ffffff;
    border-radius: 8px;
    overflow: hidden;
    box-shadow: 0 4px 12px rgba(0, 0, 0, 0.05);
  }

  .table th {
    background-color: #f0f3f5;
    color: #555555;
    font-weight: 600;
    padding: 12px;
  }

  .table td {
    padding: 14px;
    background-color: #ffffff;
    color: #333333;
    border-bottom: 1px solid #e2e6ea;
  }

  /* Dropdown Styling */
  .dropdown .btn-xs {
    background-color: #e0e4e7;
    color: #333333;
    border: none;
    font-size: 12px;
    border-radius: 4px;
  }

  .dropdown .btn-xs:hover {
    background-color: #cfd4da;
  }

  /* Scrollable Table */
  .report-table {
    white-space: nowrap;
  }
/* Button */
.nav-tabs .p-b .btn{
    width:100%;
 background: linear-gradient(145deg, #007bff, #0056b3); /* Light gradient */
    color: #ffffff;
    padding: 14px 28px;
    font-size: 14px;
    font-weight: 500;
    border: none;
    border-radius: 5px;
    box-shadow: 0 4px 8px rgba(0, 0, 0, 0.1);
    transition: background 0.3s ease, transform 0.2s ease;
}
.nav-tabs .p-b .btn:hover {
    background: linear-gradient(145deg, #0056b3, #003c82);
    transform: translateY(-2px);
}

.form .form-group__service-name span{
 display:none;
}

/* Button */
.form .modal-footer .btn-primary{
 background: linear-gradient(145deg, #007bff, #0056b3); /* Light gradient */
    color: #ffffff;
    padding: 14px 28px;
    font-size: 14px;
    font-weight: 500;
    border: none;
    border-radius: 5px;
    box-shadow: 0 4px 8px rgba(0, 0, 0, 0.1);
    transition: background 0.3s ease, transform 0.2s ease;
}

/* Button */
.form .modal-footer .btn-danger{
 background: linear-gradient(145deg, #c71f1f, #e04d4d); /* Gradient background for a professional look */
  color: #ffffff; /* Text color */
  padding: 14px 28px;
  font-size: 14px; /* Font size */
  font-weight: 500; /* Font weight */
  border: none; /* Remove default border */
  border-radius: 5px; /* Slightly rounded corners */
  box-shadow: 0 4px 8px rgba(0, 0, 0, 0.3); /* Subtle shadow for depth */
  transition: background 0.3s ease, transform 0.2s ease; /* Smooth transition for hover effects */
}

.form .modal-footer .btn-primary:hover {
    background: linear-gradient(145deg, #0056b3, #003c82);
    transform: translateY(-2px);
}
  .form .modal-footer .btn-danger:hover {
  background: linear-gradient(145deg, #e04d4d, #f76c6c); /* Darker gradient on hover */
  transform: translateY(-2px); /* Slight lift effect */
}
/* Note editable */
.note-editor .note-editing-area .note-editable{
 
   
    background-color: #e9ecef; /* Light input background */
    border-radius: 8px;
    padding: 12px;
    color: #333; /* Dark text color */
    box-shadow: inset 0 2px 4px rgba(0, 0, 0, 0.1);
    min-height: 50px;
}



/* Input */
.form > .modal-body > .form-group > input[type=text]{
 display: flex;
    
    background-color: #e9ecef; /* Light input background */
    border-radius: 8px;
    padding: 12px;
    color: #333; /* Dark text color */
    box-shadow: inset 0 2px 4px rgba(0, 0, 0, 0.1);
    min-height: 50px;
}

.swal-overlay .swal-modal .swal-icon--warning{
 display:none;
}




</style>

<div class="col-md-8">
    
<ul class="nav nav-tabs">
    <li class="p-b">
<button type="button" class="btn btn-default" data-toggle="modal" data-target="#modalDiv" data-action="new_news">Add New Announcement</button>        
 </li>
  </ul>
<div style="overflow-x:scroll;">
   <table class="table report-table">
      <thead>
         <tr>
            
            <th>Title</th>
            <th>Date</th>
            <th></th>
         </tr>
      </thead>
      <tbody>
         <?php foreach($newsList as $new): ?>
         <tr>

     <td><?=$new["news_title"]?></td>
  
  <td><?=$new["news_date"]?></td>
  
            <td class="text-right col-md-1">
              <div class="dropdown pull-right">
             
<button type="button" class="btn btn-default btn-xs pull-right" data-toggle="modal" data-target="#modalDiv" data-action="edit_news" data-id="<?=$new['id']?>">Edit</button>         

</div>
            </td>
         </tr>
         <?php endforeach; ?>
      </tbody>
   </table></div>
</div>