<?php include 'admin_security.php'; ?>
<!DOCTYPE html>
<html lang="en">
<head>
<meta charset="UTF-8">
<meta name="viewport" content="width=device-width, initial-scale=1">
 <title><?php echo htmlspecialchars($settings['site_name']); ?> Admin</title>
<link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap@5.2.3/dist/css/bootstrap.min.css">
<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.2/css/all.min.css">
<link rel="stylesheet" type="text/css" href="style.css">
<style>
/* Import Google Fonts */
@import url("//fonts.googleapis.com/css2?family=Inter:ital,wght@0,300;0,400;0,500;0,600;0,700&display=swap");

/* Container */
#container {
    font-family: 'Inter', sans-serif;
}

/* Basic styling reset */
* {
    box-sizing: border-box;
    margin: 0;
    padding: 0;
}

html {
    font-size: 16px;
}

body {
    font-family: Arial, sans-serif;
    background-color: #f8f9fa; /* Light background */
    color: #333333; /* Dark text for readability */
}

/* Container styling */
#container {
    display: flex;
    justify-content: center;
    align-items: center;
    height: 100vh;
    padding: 10px;
}

/* Box styling */
.box {
    display: flex;
    justify-content: center;
    align-items: center;
    max-width: 400px;
    width: 100%;
    background-color: #ffffff; /* White background for box */
    border-radius: 12px;
    padding: 40px;
    box-shadow: 0 4px 12px rgba(0, 0, 0, 0.1); /* Soft shadow for depth */
}

/* Form styling */
.form-box {
    display: flex;
    flex-direction: column;
    justify-content: center;
    align-items: center;
    width: 100%;
}

.ic-account {
    width: 80px;
    height: 80px;
    border-radius: 50%;
    background-color: #f1f3f5; /* Light gray for icon container */
    margin-bottom: -40px;
    top: -60px;
    position: relative;
    display: flex;
    justify-content: center;
    align-items: center;
    font-size: 36px;
    color: #5a5a5a; /* Muted icon color */
    box-shadow: 0 4px 8px rgba(0, 0, 0, 0.1);
}

.alert {
    border-radius: 5px;
    margin-top: 15px;
    padding: 10px;
    width: 100%;
    text-align: center;
}
.alert-success {
    background-color: #28a745;
    color: #ffffff;
}
.alert-danger {
    background-color: #dc3545;
    color: #ffffff;
}

/* Input fields styling */
.input-group {
    width: 100%;
    margin-bottom: 20px;
}

.input-field {
    display: flex;
    align-items: center;
    background-color: #f1f3f5; /* Light gray background */
    border-radius: 8px;
    padding: 12px;
    color: #333333;
    box-shadow: inset 0 2px 4px rgba(0, 0, 0, 0.05);
}

.input-field i {
    margin-right: 12px;
    color: #9a9a9a; /* Muted icon color */
}

.login-form-input {
    border: none;
    background: transparent;
    outline: none;
    width: 100%;
    color: #333333;
    font-size: 1rem;
}

.login-form-input::placeholder {
    color: #a9a9a9; /* Light gray placeholder */
}

/* Button styling */
.login-form-btn {
    width: 100%;
    background: linear-gradient(145deg, #0069d9, #0056b3); /* Blue gradient background */
    color: #ffffff;
    padding: 14px 28px;
    font-size: 16px;
    font-weight: 500;
    border: none;
    border-radius: 5px;
    box-shadow: 0 4px 8px rgba(0, 0, 0, 0.1);
    transition: background 0.3s ease, transform 0.2s ease;
}

.login-form-btn i {
    margin-right: 8px;
}

.login-form-btn:hover {
    background: linear-gradient(145deg, #0056b3, #004494); /* Darker gradient on hover */
    transform: translateY(-2px);
}

/* Checkbox styling */
.form-check-label {
    color: #5a5a5a;
}
.form-check-input:checked {
    background-color: #007bff;
    border-color: #007bff;
}

.form-check-input {
    background-color: #f1f3f5;
    border-color: #007bff;
}
/* Form check */
.form-box form .form-check{
 position:relative;
 top:-10px;
}


</style>
</head>
<body>
  <div id="container">
    <div class="box">
      <div class="form-box">
        <div class="ic-account"><i class="fas fa-user"></i></div>
        <?php if( $success ): ?>
        <div class="alert alert-success"><?php echo $successText; ?></div>
        <?php endif; ?>
        <?php if( $error ): ?>
        <div class="alert alert-danger"><?php echo $errorText; ?></div>
        <?php endif; ?>
        <form name="login-form" action="#" method="post">
          <div class="input-group">
            <div class="input-field">
              <i class="fa-solid fa-user"></i>
              <input class="login-form-input" type="text" name="username" placeholder="Username" required>
            </div>
          </div>
          <div class="input-group">
            <div class="input-field">
              <i class="fa-solid fa-key"></i>
              <input class="login-form-input" type="password" name="password" placeholder="Password" required>
            </div>
          </div>
          <div class="input-group">
            <div class="input-field">
              <i class="fa-solid fa-unlock"></i>
              <input class="login-form-input two_factor_input" type="number" name="two_factor_code" placeholder="Enter 2FA Code (If Setup)">
            </div>
          </div>
          <div class="form-check">
            <input type="checkbox" class="form-check-input" name="remember" id="exampleCheck1">
            <label class="form-check-label" for="exampleCheck1">Remember Me</label>
          </div>
          <button class="login-form-btn" type="submit"><i class="fas fa-sign-in-alt"></i>Login</button>
        </form>
      </div>
    </div>
  </div>
</body>
</html>
