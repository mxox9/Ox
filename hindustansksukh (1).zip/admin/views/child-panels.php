<style>
  /* General Styling */
  body {
    font-family: 'Inter', sans-serif;
    background-color: #f7f9fc;
    color: #333333;
  }

  /* Table Styling */
  .table-responsive {
    margin-top: 20px;
    overflow-x: auto;
  }

  

  /* Status and Action Styling */
  .btn-default {
    background-color: #f0f0f0;
    color: #333;
    border: 1px solid #ccc;
    border-radius: 6px;
    padding: 5px 10px;
  }

  .dropdown-menu {
    min-width: 150px;
    font-size: 0.9em;
  }

  .dropdown-menu a {
    color: #333;
    text-decoration: none;
  }

  .dropdown-menu a:hover {
    background-color: #f0f0f0;
  }
  /* Import Google Fonts */
@import url("//fonts.googleapis.com/css2?family=Inter:ital,wght@0,300;0,400;0,500;0,600;0,700;1,300;1,400;1,500;1,600;1,700&display=swap");

/* Division */
.container-fluid .row div{
 font-family:'Inter', sans-serif;
 text-transform:capitalize;
 text-align:center;
}

/* Th */
#dt tr th{
 text-align:center;
 text-transform:uppercase;
}
#dt{
    border-radius: 8px;
    border: 1px solid #ddd;
    box-shadow: 0 4px 8px rgba(0, 0, 0, 0.1);
    overflow-x: auto;
}
#dt thead{
    border: 1px solid #ddd;
    background: #f8f8f8;
    border-radius: 3px;
    position: relative;
}
/* Th */
#dt tr th{
 font-weight:600;
 font-size:14px;
}

/* Table */
#dt{
 font-size:14px;
}



</style>


<?php include 'header.php'; ?>

<div class="container-fluid">
  <div class="row">    
   <div style="overflow-x:scroll;">
  
    <table  class="table table-responsive" id="dt">
<thead>
    <tr>
<th class="p-l">ID</th>
<th>User</th>
<th>Domain</th>
<th>Created At</th>
<th>Status</th>
<th>Actions</th>
</tr>
</thead>
    <tbody>
<?php foreach($payments as $payment): ?>
<tr>
    <td class="p-l"><?php echo $payment["id"] ?></td>
    <td><?php echo $payment["username"] ?></td>
    <td><?php echo $payment["domain"] ?></td>
    <td><?php echo $payment["created_on"]; ?></td>
    <td><?php echo $payment["child_panel_status"]; ?></td>
    <td>

<div class="dropdown pull-right">
<button type="button" class="btn btn-default btn-xs dropdown-toggle btn-xs-caret" data-toggle="dropdown">Actions <span class="caret"></span></button>
<ul class="dropdown-menu">
<li>
<a href="<?php echo site_url("admin/child-panels/".$payment["id"]."/activate");?>">Status To Active</a>
<a href="<?php echo site_url("admin/child-panels/".$payment["id"]."/suspend");?>">Status To Suspended</a>
</li>

</ul>
</div>
</td>
</tr>
<?php endforeach; ?>
    </tbody>
    </table>
</div>
    </div>
</div>


<?php include 'footer.php'; ?>
