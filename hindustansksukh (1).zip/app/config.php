<?php
$url = $_SERVER["SERVER_NAME"];  
define('PATH', realpath('.'));
define('SUBFOLDER', false);
define('URL', 'https://skinstagrow.store');
define('STYLESHEETS_URL', '//skinstagrow.store' );
date_default_timezone_set('Asia/Kolkata');
error_reporting(0);
return [
  'db' => [
    'name'    =>  'jasssk12_sukh1' ,
    'host'    =>  'localhost',
    'user'    =>  'jasssk12_sukh1' ,
    'pass'    =>  'jasssk12_sukh1' ,
    'charset' =>  'utf8mb4' 
  ]
];
?>