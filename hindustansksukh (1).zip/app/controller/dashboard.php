<?php
if(!defined('BASEPATH')) {
   die('Direct access to the script is not allowed');
}
if( $_SESSION["msmbilisim_userlogin"] != 1  || $user["client_type"] == 1  ){
  header("Location:".site_url('logout'));
}

?>